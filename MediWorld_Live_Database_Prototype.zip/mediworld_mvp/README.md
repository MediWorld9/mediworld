# MediWorld MVP — live label search prototype

This is a static website prototype for educational medicine information.

## Run
Open `index.html` in a modern browser, or publish the folder with GitHub Pages.

## Live data currently connected
- Search requests are sent directly from the browser to the public openFDA Drug Product Labeling API.
- The interface displays sections that are present in a returned U.S. product label, such as indications, warnings, contraindications, adverse reactions, dosage and administration, and drug interactions.
- openFDA label content is not a complete global medicine database. It is based on product-label submissions, fields vary by product, and FDA cautions that submitted label content may not be verified by FDA or identical to products currently marketed.
- No API key is required for low-volume testing; openFDA publishes request limits and recommends an API key for regular use: https://open.fda.gov/apis/authentication/

## Important limitations
- This is not a clinical decision-support tool and must not be used to diagnose, prescribe, calculate doses, or decide whether to start/stop a medicine.
- The current live data coverage is U.S. FDA labels only. Bangladesh DGDA and other national regulatory databases are not connected yet.
- Medicine photo upload remains preview-only; it does not identify medicines.
- The language selector is a visual prototype; complete verified translations are not implemented.
- No backend, account system, interaction checker, or Android/iOS app is included.

## Next production steps
1. Obtain and validate authorized national medicine datasets (starting with Bangladesh DGDA).
2. Add country, product strength, dosage form, manufacturer, and registration identifiers to matching.
3. Add reviewed translations, provenance, update timestamps, privacy controls, and clinical governance.
4. Build a secure backend before adding image recognition or personal medication features.
